;	Update all of this information to reflect your own details and the prac
;	Author:     DN MBOYI 222019179
;	Template document
.386
.MODEL FLAT ; Flat memory model
.STACK 4096 ; 4096 bytes
INCLUDE io.inc
; Exit function
ExitProcess PROTO NEAR32 stdcall, dwExitCode:DWORD

; The data section stores all global variables
.DATA
strPromptUser BYTE "Please enter any number between 0 and 100:", 0
strErrorMessage BYTE "The number you have entered is not found!!!", 0
strNewLine BYTE 10, 0
strValueProduced BYTE "The value produced by shaw is: ", 0
strExit BYTE "Do you still want to continue? (0 - No, 1 - Yes)? ", 0

; The code section may contain multiple tags such as _start, which is the entry
; point of this assembly program
.CODE
;Now we are starting with the recursive function:

shaw PROC NEAR32
; Set up the Stack frame 
    PUSH ebp
    MOV  ebp, esp
    
; Save your needed registers
    PUSH edx
    PUSH ecx
    PUSH ebx

    PUSHFD
    
; Ensure we get the parameter n
    MOV eax, [ebp+8]
    
; We check the situation when: n <= 0
    CMP eax, 0
    JG ShawLoop
    MOV eax, 1
    JMP EndShawLoop
    
; We check the situation when: 0 < n <= 5
ShawLoop:
    CMP eax, 5
    JG RecursionLoop
    SHL eax, 1; n << 1 (n * 2)
    JMP EndShawLoop
    
; Lastly, we check when: n >= 6
RecursionLoop:

 ; Calculating the shaw(n >> 3)
    MOV ebx, eax        
    SHR eax, 3 ;This is when n >> 3
    PUSH eax
    CALL shaw
    MOV ecx, eax ; Save result of shaw(n >> 3)
    
 ; Calculating the shaw(n - 3)
    MOV eax, ebx 
    SUB eax, 3 ; n - 3
    PUSH eax
    CALL shaw
    
; Now we combining the results of the two shaws:
    ADD eax, ecx ; shaw(n >> 3) + shaw(n - 3)

EndShawLoop:

; Restore registers
    POPFD
    POP ebx
    POP ecx
    POP edx
    
; Clean up stack and return
    MOV esp, ebp
    POP ebp
    RET 4
shaw ENDP

_start:

StartLoop:

; Prompt the user for input
PromptUser:
    LEA eax, strPromptUser
    PUSH eax
    CALL OutputStr
    CALL InputInt
    
    CMP eax, 0
    JL ErrorLoop
    CMP eax, 100
    JG ErrorLoop
    JMP CorrectLoop

ErrorLoop:
    LEA eax, strErrorMessage
    PUSH eax
    CALL OutputStr
    LEA eax, strNewLine
    PUSH eax
    CALL OutputStr
    JMP PromptUser
    
CorrectLoop:

    PUSH eax
    CALL shaw
    
; Display the results
    MOV ebx, eax; Save result at the ebx register
    LEA eax, strValueProduced
    PUSH eax
    CALL OutputStr
    PUSH ebx
    CALL OutputInt
    LEA eax, strNewLine
    PUSH eax
    CALL OutputStr

; Ask if user wants to continue
continue:
    LEA eax, strExit
    PUSH eax
    CALL OutputStr
    CALL InputInt
    
    CMP eax, 1
    JE StartLoop; Continue if input is 1

 ; Exit program
    MOV eax, 0
    PUSH eax
    CALL ExitProcess

	; Most of your initial code will be under the _start tag.
	; The _start tag is just a memory address referenced by the Public indicator
	; highlighting which functions are available to calling functions.
	; _start gets called by the operating system to start this process.
 

	; We call the Operating System ExitProcess system call to close the process.
	INVOKE ExitProcess, 0
Public _start
END
